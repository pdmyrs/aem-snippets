package org.example;

import java.net.URI;
import java.net.URISyntaxException;

import com.adobe.aem.graphql.client.AEMHeadlessClient;
import com.adobe.aem.graphql.client.AEMHeadlessClientException;
import com.adobe.aem.graphql.client.GraphQlResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) throws URISyntaxException {
        System.out.println("Hello World!");

        AEMHeadlessClient aemHeadlessClient = AEMHeadlessClient.builder()
        .endpoint(new
        URI("http://localhost:4502/content/cq%3Agraphql/my-project/endpoint.json"))
        .basicAuth("admin", "admin")
        .build();

        // AEMHeadlessClient aemHeadlessClient = AEMHeadlessClient.builder()
        //         .endpoint(new URI("http://localhost:4502/graphql/execute.json"))
        //         .basicAuth("admin", "admin")
        //         .build();

        // String query = "{\n" +
        // " teamList{\n" +
        // " items{ \n" +
        // " _path\n" +
        // " } \n" +
        // " }\n" +
        // "}";




        String query = "{\n" +
        " teamList{\n" +
        " items{ \n" +
        "   _path\n" +
        "   title\n" +
        "   shortName\n" +
        "     teamMembers {\n" +
        "        fullName\n" + 
        "        occupation\n" + 
        "     } \n" +
        "   } \n" +
        " }\n" +
        "}";

// String query = "{\n" +
// " teamList{\n" +
// " items{ \n" +
//         teamList {
//             items {
//                 _path
//                 title
//                 shortName
//                 description {
//                     plaintext
//                 }
//                 teamMembers {
//                     fullName
//                     occupation
//                 }
//             }
//         }



        try {
            GraphQlResponse response = aemHeadlessClient.runQuery(query);
            // GraphQlResponse response = aemHeadlessClient.runPersistedQuery("/my-project/all-teams");
            JsonNode data = response.getData();
            System.out.println(prettyPrintJsonString(data));
            // ... use the data
        } catch (AEMHeadlessClientException e) {
            // e.getMessage() will contain an error message (independent of type of error)
            // if a response was received, e.getGraphQlResponse() will return it (otherwise
            // null)

            if (e.getGraphQlResponse() != null) {
                System.out.println(e.getGraphQlResponse());
            } else {
                System.out.println(e.getMessage());
            }
        }

    }

    public static String prettyPrintJsonString(JsonNode jsonNode) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            Object json = mapper.readValue(jsonNode.toString(), Object.class);
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(json);
        } catch (Exception e) {
            return "Sorry, pretty print didn't work";
        }
    }

}
